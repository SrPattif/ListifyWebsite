<?php
    $listifyDomain = 'http://localhost';
    $listifyRedirectURI = 'http://localhost/user/';
    $spotifyAPIKey = 'MDBmZThhODg4MzAzNDAwMjkzYTM2YTFmYjgyZWMxNDU6YjdmZmE4MmVhZjI3NDk1OWIyNWZjYWZhYzViNzhlMTE=';
?>